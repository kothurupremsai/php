<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Picosite : Reservation</title>
</head>
<body>
    <header>
        <h1>Picosite : Reservation</h1>
        <nav id="principal">
        <li><a href="index.php">Home</a></li>
        <li><a href="catalog.php">Catalog</a> </li>
        <li><a href="reservation.php">Booking</a></li>
        </nav>
    </header>
    <main></main>
</body>
</html>